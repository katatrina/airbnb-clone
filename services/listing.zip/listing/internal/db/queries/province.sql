-- name: ListProvinces :many
SELECT *
FROM provinces
ORDER BY full_name;