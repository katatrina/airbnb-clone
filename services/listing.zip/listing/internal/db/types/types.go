package types

type ListingStatus string

const (
	ListingStatusDraft    ListingStatus = "draft"
	ListingStatusActive   ListingStatus = "active"
	ListingStatusInactive ListingStatus = "inactive"
)

type ListingCurrency string

const (
	ListingCurrencyVND ListingCurrency = "VND"
)
